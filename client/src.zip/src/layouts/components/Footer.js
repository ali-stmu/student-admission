const CustomFooter = props => {
  console.log('Footer:', props)
  return <h6>Custom Footer</h6>
}

export default CustomFooter
