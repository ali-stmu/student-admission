const CustomMenu = props => {
  console.log('Menu:', props)
  return <h6>Custom Menu</h6>
}

export default CustomMenu
