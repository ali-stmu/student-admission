import React, { useState } from "react";
import { selectThemeColors } from "@utils";

import {
  Label,
  FormGroup,
  Row,
  Col,
  Button,
  Form,
  Input,
  CustomInput,
} from "reactstrap";

function AcademicRecords() {
  const [records, setRecords] = useState([
    {
      resultStatus: "",
      qualification: "",
      boardUniversity: "",
      passingYear: "",
      totalMarksCGPA: "",
      obtainedMarksCGPA: "",
    },
  ]);

  const addRecord = () => {
    setRecords([
      ...records,
      {
        resultStatus: "",
        qualification: "",
        boardUniversity: "",
        passingYear: "",
        totalMarksCGPA: "",
        obtainedMarksCGPA: "",
      },
    ]);
  };

  const handleRecordChange = (e, index) => {
    const { name, value } = e.target;
    const updatedRecords = [...records];
    updatedRecords[index] = {
      ...updatedRecords[index],
      [name]: value,
    };
    setRecords(updatedRecords);
  };

  const calculatePercentage = (total, obtained) => {
    return ((obtained / total) * 100).toFixed(2);
  };

  return (
    <div>
      {records.map((record, index) => (
        <div key={index}>
          <label>Result Status:</label>
          <select
            name="resultStatus"
            value={record.resultStatus}
            onChange={(e) => handleRecordChange(e, index)}
          >
            <option value=""></option>
            <option value="Pass">Pass</option>
            <option value="Fail">Fail</option>
          </select>

          <label>Qualification:</label>
          <select
            name="qualification"
            value={record.qualification}
            onChange={(e) => handleRecordChange(e, index)}
          >
            <option value=""></option>
            <option value="Bachelor's">Bachelor's</option>
            <option value="Master's">Master's</option>
            <option value="PhD">PhD</option>
          </select>

          <label>Board/University:</label>
          <select
            name="boardUniversity"
            value={record.boardUniversity}
            onChange={(e) => handleRecordChange(e, index)}
          >
            <option value=""></option>
            <option value="ABC University">ABC University</option>
            <option value="XYZ Board">XYZ Board</option>
          </select>

          <label>Passing Year:</label>
          <input
            type="text"
            name="passingYear"
            value={record.passingYear}
            onChange={(e) => handleRecordChange(e, index)}
          />

          <label>Total Marks/CGPA:</label>
          <input
            type="text"
            name="totalMarksCGPA"
            value={record.totalMarksCGPA}
            onChange={(e) => handleRecordChange(e, index)}
          />

          <label>Obtained Marks/CGPA:</label>
          <input
            type="text"
            name="obtainedMarksCGPA"
            value={record.obtainedMarksCGPA}
            onChange={(e) => handleRecordChange(e, index)}
          />

          <label>Percentage:</label>
          <input
            type="text"
            value={calculatePercentage(
              record.totalMarksCGPA,
              record.obtainedMarksCGPA
            )}
            readOnly
          />
        </div>
      ))}

      <button onClick={addRecord}>Add More Records</button>
    </div>
  );
}

export default AcademicRecords;
